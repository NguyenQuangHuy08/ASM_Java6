package com.example.assignment.request;
/*
    @diemdz
*/

public class GHCTRequest {
}

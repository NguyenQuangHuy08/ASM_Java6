package com.example.assignment.respone;
/*
    @diemdz
*/

public class GHCTRespone {
}

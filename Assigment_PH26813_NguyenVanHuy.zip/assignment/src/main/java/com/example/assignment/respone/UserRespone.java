package com.example.assignment.respone;
/*
 *  @author diemdz
 */

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class UserRespone {
    private String email;
    private String matKhau;
    private String tenChucVu;
}

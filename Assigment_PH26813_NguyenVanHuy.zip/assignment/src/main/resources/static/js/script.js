window.addEventListener('load', function() {
    // Ẩn hiệu ứng loading
    document.querySelector('.loader').style.display = 'none';
});